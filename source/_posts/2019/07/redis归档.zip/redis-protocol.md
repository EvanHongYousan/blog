---
title: redis 通信协议
date: 2019-07-08 15:30:58
categories: [tech]
tags: [redis]
---

redis 通信协议：RESP(Redis Serialization Protocol)
<escape><!-- more --></escape>

{% asset_img overview.png %}
