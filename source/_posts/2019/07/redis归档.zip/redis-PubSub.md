---
title: redis PubSub
date: 2019-07-09 17:45:58
categories: [tech]
tags: [redis]
---

PublisherSubscriber，发布者订阅者模型，支持消息多播
<escape><!-- more --></escape>

{% asset_img overview.png %}
