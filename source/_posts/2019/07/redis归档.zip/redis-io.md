---
title: redis 线程io模型
date: 2019-07-07 15:30:58
categories: [tech]
tags: [redis]
---

redis 是个单线程程序
<escape><!-- more --></escape>

{% asset_img overview.png %}
