---
title: redis 管道
date: 2019-07-09 16:32:58
categories: [tech]
tags: [redis]
---

Redis 管道 (Pipeline) 本身并不是 Redis 服务器直接提供的技术，这个技术本质上是由客户端提供的，跟服务器没有什么直接的关系。
<escape><!-- more --></escape>

{% asset_img overview.png %}
